const btn = document.querySelector(".getBtn");
btn.addEventListener("click", async () => {
  let [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: captureData,
  });
});

let selectedAddressElement;
function captureData() {
  const dataObject = {};
  const elements = document.querySelectorAll(".Io6YTe");
  for (const element of elements) {
    if (!element.innerText.includes("You visited in")) {
      // This element does not contain the text "You visited in"
      // You can perform your desired actions here
      selectedAddressElement = element;
      break;
    }
  }
  const currentStatusElement = document.querySelector(".ZDu9vd");
  const websiteElement = document.querySelector(".ITvuef");

  const button = document.querySelector(".CsEnBe");
  const nameElement = document.querySelector(".DUwDvf");

  // Define the selectors to search for contact number
  const selectors = [
    // Add your contact number selectors here
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(8) > div:nth-child(4) > button > div",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(7) > div:nth-child(5) > button > div > div.rogA2c",
    "#QA0Szd > div > div > div.w6VYqd > div:nth-child(2) > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(9) > div:nth-child(5) > button > div > div.rogA2c",
    "#QA0Szd > div > div > div.w6VYqd > div:nth-child(2) > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(7) > div:nth-child(6) > button > div > div.rogA2c",
    "#QA0Szd > div > div > div.w6VYqd > div:nth-child(2) > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(9) > div:nth-child(7) > button > div > div.rogA2c",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(17) > div:nth-child(6) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(11) > div:nth-child(4) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(7) > div:nth-child(4) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(9) > div:nth-child(6) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db",
    "#QA0Szd > div > div > div.w6VYqd > div.bJzME.tTVLSc > div > div.e07Vkf.kA9KIf > div > div > div:nth-child(9) > div:nth-child(10) > button > div > div.rogA2c > div.Io6YTe.fontBodyMedium.kR99db",
  ];

  let contactNumberElement = null;

  // Loop through the selectors to find the contact number element
  for (const selector of selectors) {
    contactNumberElement = document.querySelector(selector);
    if (contactNumberElement) {
      // If an element is found, break the loop
      break;
    }
  }

  // Now, you have the selected element in the contactNumberElement variable.
  const url = window.location.href;

  // Function to extract LatLng from the URL
  function getLatLngFromURL(url) {
    const regex = /@([-+]?\d*\.\d+),([-+]?\d*\.\d+)/;
    const match = url.match(regex);
    const latLng = [match[1], match[2]];
    return latLng;
  }

  // Call the function to get LatLng
  const latLng = getLatLngFromURL(url);

  dataObject.name = nameElement ? nameElement.innerText : null;
  dataObject.address = selectedAddressElement
    ? selectedAddressElement.innerText
    : null;
  dataObject.currentStatus = currentStatusElement
    ? currentStatusElement.innerText
    : null;
  dataObject.website = websiteElement ? websiteElement.innerText : null;

  // Extract the contact number value
  const numberValue = parseFloat(
    contactNumberElement ? contactNumberElement.innerText : ""
  );

  // Check if the conversion was successful and numberValue is a valid number
  if (!isNaN(numberValue)) {
    dataObject.contactNumber = contactNumberElement.innerText;
  } else {
    dataObject.contactNumber = null;
  }

  dataObject.latitude = Number(latLng[0]);
  dataObject.longitude = Number(latLng[1]);

  // Create an object with the data to be sent to the API
  const postData = {
    addr: dataObject.address || "null",
    number: dataObject.contactNumber || "null",
    status: dataObject.currentStatus || "null",
    website: dataObject.website || "null",
    place_name: dataObject.name || "null",
    latitude: dataObject.latitude || "null",
    longitude: dataObject.longitude || "null",
  };
  chrome.runtime.sendMessage({ postData });
}

// Handler to receive the data
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  let response = request.postData;
  const addressInput = (document.getElementById("addr").value = response.addr);
  const addressNumber = (document.getElementById("number").value =
    response.number);
  const addressStatus = (document.getElementById("status").value =
    response.status);
  const addressWebsite = (document.getElementById("website").value =
    response.website);
  const addressPlaceName = (document.getElementById("place_name").value =
    response.place_name);
  const addressLatitude = (document.getElementById("latitude").value =
    response.latitude);
  const addressLongitude = (document.getElementById("longitude").value =
    response.longitude);

  let updatedAddressValue;
  let updatedNumberValue;
  let updatedStatusValue;
  let updatedWebsiteValue;
  let updatedPlaceNameValue;

  // Add a change event listener to the input elements
  document.getElementById("addr").addEventListener("change", function (event) {
    updatedAddressValue = event.target.value;
  });

  document
    .getElementById("number")
    .addEventListener("change", function (event) {
      updatedNumberValue = event.target.value;
    });

  document
    .getElementById("status")
    .addEventListener("change", function (event) {
      updatedStatusValue = event.target.value;
    });

  document
    .getElementById("website")
    .addEventListener("change", function (event) {
      updatedWebsiteValue = event.target.value;
    });

  document
    .getElementById("place_name")
    .addEventListener("change", function (event) {
      updatedPlaceNameValue = event.target.value;
    });

  // ###############################
  // For autocompelete

  const typeInputField = document.getElementById("p_type");
  const subTypeInputField = document.getElementById("sub_type");
  const typeSuggestionsList = document.getElementById("suggestionsPtype");
  const subTypeSuggestionsList = document.getElementById("suggestionsSubType");
  let uniqueTypes = new Set();
  let subTypesData = [];

  typeInputField.addEventListener("input", debounce(fetchTypeSuggestions, 300));
  subTypeInputField.addEventListener(
    "input",
    debounce(fetchSubTypeSuggestions, 300)
  );

  // Trigger fetching type suggestions when the input field is clicked
  typeInputField.addEventListener("focus", () => {
    fetchTypeSuggestions();
  });

  async function fetchTypeSuggestions() {
    const input = typeInputField.value;
    // You can adjust the minimum input length as per your preference.
    if (input.length < 0) {
      typeSuggestionsList.style.display = "block"; // Show suggestions when the input field is clicked.
      displayUniqueTypes();
      return;
    }

    const apiUrl = "https://api.admin.barikoi.com/api/v2/get-all-sub-type";

    try {
      const response = await fetch(apiUrl);
      const data = await response.json();

      uniqueTypes.clear(); // Clear the set to start with a fresh list of unique types.

      // Add unique types to the set based on the input.
      data.forEach((item) => {
        if (item.type.toLowerCase().includes(input.toLowerCase())) {
          uniqueTypes.add(item.type);
        }
      });

      const uniqueTypeSuggestions = Array.from(uniqueTypes);

      if (uniqueTypeSuggestions.length > 0) {
        const suggestionItems = uniqueTypeSuggestions
          .map((item) => {
            return `<li>${item}</li>`;
          })
          .join("");

        typeSuggestionsList.innerHTML = suggestionItems;
        typeSuggestionsList.style.display = "block";

        typeSuggestionsList.querySelectorAll("li").forEach((item) => {
          item.addEventListener("click", () => {
            typeInputField.value = item.textContent;
            typeSuggestionsList.style.display = "none";
            // Clear sub-type input and its suggestions when type is selected.
            subTypeInputField.value = "";
            subTypeSuggestionsList.style.display = "none";
          });
        });
      } else {
        typeSuggestionsList.style.display = "none";
      }
    } catch (error) {
      console.error("Error fetching data: ", error);
    }
  }

  function displayUniqueTypes() {
    const uniqueTypeSuggestions = Array.from(uniqueTypes);

    if (uniqueTypeSuggestions.length > 0) {
      const suggestionItems = uniqueTypeSuggestions
        .map((item) => {
          return `<li>${item}</li>`;
        })
        .join("");

      typeSuggestionsList.innerHTML = suggestionItems;
      typeSuggestionsList.style.display = "block";

      typeSuggestionsList.querySelectorAll("li").forEach((item) => {
        item.addEventListener("click", () => {
          typeInputField.value = item.textContent;
          typeSuggestionsList.style.display = "none";
          // Clear sub-type input and its suggestions when type is selected.
          subTypeInputField.value = "";
          subTypeSuggestionsList.style.display = "none";
        });
      });
    } else {
      typeSuggestionsList.style.display = "none";
    }
  }
  subTypeInputField.addEventListener("focus", () => {
    fetchSubTypeSuggestions();
  });

  async function fetchSubTypeSuggestions() {
    const selectedType = typeInputField.value;
    const input = subTypeInputField.value;
    if (input.length < 0 || selectedType.length < 1) {
      subTypeSuggestionsList.style.display = "none";
      return;
    }

    // Filter subTypesData based on the selectedType.
    const filteredSubTypes = subTypesData.filter(
      (item) =>
        item.type === selectedType &&
        item.subtype.toLowerCase().includes(input.toLowerCase())
    );

    if (filteredSubTypes.length > 0) {
      const suggestionItems = filteredSubTypes
        .map((item) => {
          return `<li>${item.subtype}</li>`;
        })
        .join("");

      subTypeSuggestionsList.innerHTML = suggestionItems;
      subTypeSuggestionsList.style.display = "block";

      subTypeSuggestionsList.querySelectorAll("li").forEach((item) => {
        item.addEventListener("click", () => {
          subTypeInputField.value = item.textContent;
          subTypeSuggestionsList.style.display = "none";
        });
      });
    } else {
      subTypeSuggestionsList.style.display = "none";
    }
  }

  // Fetch and store the subtypes data.
  async function fetchSubTypeData() {
    // Replace the URL with the actual API endpoint
    const apiUrl = "https://api.admin.barikoi.com/api/v2/get-all-sub-type";

    try {
      const response = await fetch(apiUrl);
      subTypesData = await response.json();
      displayUniqueTypes(); // Display unique types when the data is loaded.
    } catch (error) {
      console.error("Error fetching data: ", error);
    }
  }

  // Fetch subtypes data when the page loads.
  fetchSubTypeData();

  function debounce(func, delay) {
    let timeout;
    return function () {
      const context = this;
      const args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(context, args), delay);
    };
  }

  document.addEventListener("click", function (event) {
    if (!typeInputField.contains(event.target)) {
      // Clicked outside the typeInputField. Hide the type suggestion list.
      typeSuggestionsList.style.display = "none";
    }

    if (!subTypeInputField.contains(event.target)) {
      // Clicked outside the subTypeInputField. Hide the subType suggestion list.
      subTypeSuggestionsList.style.display = "none";
    }
  });

  // #######################################
  //

  const btnSubmit = document.querySelector(".submitBtn");

  btnSubmit.addEventListener("click", async () => {
    const inputFields = document.querySelectorAll(".inputClass");
    let hasEmptyField = false;

    // Check if any input field is empty
    inputFields.forEach((inputField) => {
      if (inputField.value.trim() === "") {
        inputField.classList.add("error");
        hasEmptyField = true;
      } else {
        inputField.classList.remove("error");
      }
    });

    // Check if p_type and sub_type are empty
    if (
      document.getElementById("p_type").value === "" ||
      document.getElementById("sub_type").value === ""
    ) {
      document.getElementById("p_type").classList.add("error");
      document.getElementById("sub_type").classList.add("error");
      hasEmptyField = true;
    } else {
      document.getElementById("p_type").classList.remove("error");
      document.getElementById("sub_type").classList.remove("error");
    }

    // Display or hide the error message
    const errorMessage = document.getElementById("errorMessage");
    if (hasEmptyField) {
      errorMessage.textContent = "Please fill in all required fields.";
      errorMessage.style.display = "block";
    } else {
      errorMessage.textContent = ""; // Clear the error message
      errorMessage.style.display = "none";

      // Add event listeners for "change" event on "p_type" and "sub_type" fields
      document.getElementById("p_type").addEventListener("change", function () {
        this.style.backgroundColor = ""; // Reset the background color
        removeErrorMessage(); // Remove the error message
      });

      document
        .getElementById("sub_type")
        .addEventListener("change", function () {
          this.style.backgroundColor = ""; // Reset the background color
          removeErrorMessage(); // Remove the error message
        });

      function removeErrorMessage() {
        const errorMessage = document.getElementById("errorMessage");
        errorMessage.textContent = ""; // Clear the error message
        errorMessage.style.display = "none";
      }

      const postDataInput = {
        addr:
          updatedAddressValue === "null"
            ? null
            : updatedAddressValue || addressInput || "null",
        number: updatedNumberValue || addressNumber || "null",
        status: updatedStatusValue || addressStatus || "null",
        website: updatedWebsiteValue || addressWebsite || "null",
        place_name: updatedPlaceNameValue || addressPlaceName || "null",
        latitude: document.getElementById("latitude").value || "null",
        longitude: document.getElementById("longitude").value || "null",
        p_type: document.getElementById("p_type").value || "null",
        sub_type: document.getElementById("sub_type").value || "null",
      };

      let [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });

      // Check if p_type and sub_type are empty
      // Check if p_type and sub_type are empty
      if (
        postDataInput.p_type === "null" ||
        postDataInput.sub_type === "null"
      ) {
        // Set the background color to red for the input fields with no value
        if (postDataInput.p_type === "null") {
          document.getElementById("p_type").style.backgroundColor = "red";
        }
        if (postDataInput.sub_type === "null") {
          document.getElementById("sub_type").style.backgroundColor = "red";
        }
        return; // Stop further execution
      } else {
        // Reset the background color to its default
        document.getElementById("p_type").style.backgroundColor = "";
        document.getElementById("sub_type").style.backgroundColor = "";
      }

      // If both p_type and sub_type have values, proceed to submit the data
      postDataToApi(postDataInput);
    }
  });

  function postDataToApi(postDataInput) {
    const formData = new FormData();
    formData.append(
      "addr",
      postDataInput.addr === "null" ? "" : postDataInput.addr || ""
    );
    formData.append(
      "number",
      postDataInput.number === "null" ? "" : postDataInput.number || ""
    );
    formData.append(
      "status",
      postDataInput.status === "null" ? "" : postDataInput.status || ""
    );
    formData.append(
      "website",
      postDataInput.website === "null" ? "" : postDataInput.website || ""
    );
    formData.append(
      "place_name",
      postDataInput.place_name === "null" ? "" : postDataInput.place_name || ""
    );
    formData.append(
      "latitude",
      postDataInput.latitude === "null" ? "" : postDataInput.latitude || ""
    );
    formData.append(
      "longitude",
      postDataInput.longitude === "null" ? "" : postDataInput.longitude || ""
    );
    formData.append(
      "p_type",
      postDataInput.p_type === "null" ? "" : postDataInput.p_type || ""
    );
    formData.append(
      "sub_type",
      postDataInput.sub_type === "null" ? "" : postDataInput.sub_type || ""
    );

    const formDataObject = {};
    for (const [key, value] of formData.entries()) {
      formDataObject[key] = value;
    }

    fetch("https://scraping.barikoimaps.dev/bkoi/store", {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          alert("Data sent successfully.");
        } else {
          console.error("Failed to send data.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }
});

bkoigl.accessToken = "NDE2NzpVNzkyTE5UMUoy"; // required
const map = new bkoigl.Map({
  container: "map",
  center: [90.3938010872331, 23.821600277500405],
  zoom: 12,
});

document.querySelector(".getBtn").addEventListener("click", function () {
  console.log(
    "clicked",
    document.getElementById("longitude").value,
    document.getElementById("latitude").value
  );

  const longitude = parseFloat(document.getElementById("longitude").value);
  const latitude = parseFloat(document.getElementById("latitude").value);

  if (isNaN(longitude) || isNaN(latitude)) {
    console.error("Invalid longitude or latitude");
    return;
  }

  new bkoigl.Marker({ dragable: true })
    .setLngLat([longitude, latitude])
    .addTo(map);
});
